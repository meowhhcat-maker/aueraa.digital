# AUERAA.DIGITAL website starter

## Files
- `index.html` — homepage
- `services.html` — services overview
- `content-creation.html`, `digital-marketing.html`, `website-development.html`, `application-development.html` — individual service pages
- `packages.html`, `portfolio.html`, `about.html`, `insights.html`, `contact.html`, `faq.html`
- `privacy.html`, `terms.html`, `refunds.html` — starter policy pages to customize
- `assets/style.css` — responsive styling and animations
- `assets/script.js` — mobile navigation and contact form email handoff

## Important setup before publishing
1. Search all files for `YOUR-DOMAIN.example` and replace it with your actual HTTPS domain. Update each canonical URL to the correct final page URL.
2. In `contact.html`, replace `YOUR_EMAIL@example.com` with your real business email in both the mailto link and `data-email` attribute. This form opens the visitor's email application; it does not store enquiries. For stored submissions, connect Google Forms or a secure backend.
3. Replace sample portfolio concepts with your real work or keep them clearly labelled as concept projects.
4. Add actual package prices, currency, policies, business details, and links to your social profiles.
5. Review the legal policy templates before publication.
6. Add your sitemap and verify your live domain in Google Search Console where supported.

## Preview locally
Open `index.html` in a browser. For a local server, run `python -m http.server 8000` in this folder and open `http://localhost:8000`.

## Google Sites note
Google Sites does not let you replace the entire site with these HTML files. This is a standalone coded website bundle that can be hosted on a web host. To keep using Google Sites, build the pages in the Sites editor and embed only supported widgets or snippets; you cannot upload this whole project as the source of a Google Sites site.
